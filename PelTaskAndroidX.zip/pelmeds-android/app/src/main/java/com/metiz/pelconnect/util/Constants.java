package com.metiz.pelconnect.util;

import com.metiz.pelconnect.Application;

public class Constants {
    public static final String ChangePasswordDayCount = "ChangePasswordDayCount";
    public static final int PasswordChangeNotificationPeriods = 5;
    public static final String LastPasswordChangeDate = "LastpasswordChangeDate";
    public static final String PasswordChangeNotified = "PasswordChangeNotified";

    public static int getPasswordChangeDuration() {
        if (Application.getPrefranceData(Constants.ChangePasswordDayCount).isEmpty()){
            Application.setPreferences(Constants.ChangePasswordDayCount,"90");
            return 90;
        }else {
            return Integer.parseInt(Application.getPrefranceData(Constants.ChangePasswordDayCount));
        }
    }
}
