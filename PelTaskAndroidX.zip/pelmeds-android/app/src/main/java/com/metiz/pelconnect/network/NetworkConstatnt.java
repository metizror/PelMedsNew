package com.metiz.pelconnect.network;

/**
 * Created by espl on 27/9/16.
 */
public class NetworkConstatnt {

    public static final String data = "data";
    public static final String errors = "errors";
    public static final String jsondata = "jsondata";
    public static final String success = "success";
    // custome error message while user will not get any reasponce or volly time out error
    public static final String volleyMessage = "Something went wrong. " +
            "Please, try after sometime.";


    public static final String OCD = "Offers Coupons & Deals";
    public static final String INTERNET_CONNECTION_IS_NOT_AVAILABLE = "Internet connection is not available";
    public static final String View = "View";
    public static final String Cancel = "Cancel";
    public static final String RETRY = "Retry";


}
