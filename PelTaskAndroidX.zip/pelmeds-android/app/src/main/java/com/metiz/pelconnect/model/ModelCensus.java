package com.metiz.pelconnect.model;

public class ModelCensus {

    /**
     * KeyText : Id
     * ValueText : 1852
     * isDisplayMobile : false
     */

    private String KeyText;
    private String ValueText;
    private boolean isDisplayMobile;

    public String getKeyText() {
        return KeyText;
    }

    public void setKeyText(String KeyText) {
        this.KeyText = KeyText;
    }

    public String getValueText() {
        return ValueText;
    }

    public void setValueText(String ValueText) {
        this.ValueText = ValueText;
    }

    public boolean isIsDisplayMobile() {
        return isDisplayMobile;
    }

    public void setIsDisplayMobile(boolean isDisplayMobile) {
        this.isDisplayMobile = isDisplayMobile;
    }
}
