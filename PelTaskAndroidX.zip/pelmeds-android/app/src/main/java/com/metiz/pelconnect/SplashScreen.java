package com.metiz.pelconnect;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.metiz.pelconnect.util.MyReceiver;

import java.util.Map;

public class SplashScreen extends AppCompatActivity {
    private static int SPLASH_TIME_OUT = 500;
    private BroadcastReceiver MyReceiver = null;

    TextView applicationVersion;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        MyReceiver = new MyReceiver();
        checkApplicationVersion();
     /*   if (Utils.checkInternetConnection(this)) {

            checkApplicationVersion();
            FirebaseApp.initializeApp(this);
            applicationVersion = (TextView) findViewById(R.id.application_version);
            PackageInfo pInfo = null;
            try {
                pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            String version = pInfo.versionName;
            applicationVersion.setText("Version " + version);
        }*/
        FirebaseApp.initializeApp(this);
        applicationVersion = (TextView) findViewById(R.id.application_version);
        PackageInfo pInfo = null;
        try {
            pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String version = pInfo.versionName;
        applicationVersion.setText("Version " + version);
        boolean isSessionLogoutMin = Application.getPrefranceDataBoolean("isSessionLogoutMin");
        Application.setPreferencesBoolean("isLogin", false);
        Application.clearPrefrences();
        Application.setPreferencesBoolean("isSessionLogoutMin", isSessionLogoutMin);
    }

    @Override
    protected void onResume() {
        super.onResume();
        broadcastIntent();
//        if (Utils.checkInternetConnection(this)) {
        Log.e("TAG", "onResume: internet connected");
        //moveToNextScreen();

        //   checkApplicationVersion();

//        }
    }

    @Override
    protected void onPause() {
        super.onPause();
//        unregisterReceiver(MyReceiver);
    }

    private void broadcastIntent() {
//         registerReceiver(MyReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
    }

    private void moveToNextScreen() {

        if (Application.getPrefranceDataBoolean("isForceUpdate")) {
            openUpdateDialog();
            return;
        }

        Application.setPreferencesBoolean("isForceUpdate", false);
        new Handler().postDelayed(() -> {
            if (Application.getPrefranceDataBoolean("isLogin")) {

                Intent i = new Intent(SplashScreen.this, PatientListActivityNew.class);
                i.putExtra("isFromSpash", true);
                startActivity(i);
                finish();
            } else {

                Intent i = new Intent(SplashScreen.this, LoginActivity.class);
                startActivity(i);
                finish();
            }
        }, SPLASH_TIME_OUT);

    }


    private void openUpdateDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(SplashScreen.this);
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == DialogInterface.BUTTON_POSITIVE) {
                    //Yes button clicked
                    openPlayStore();
                }
            }
        };
        builder.setMessage("You have to update application to continue user this app, as we made so many changes").setPositiveButton("Update", dialogClickListener).show();
        AlertDialog dialog = builder.create();
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (!dialog.isShowing())
            dialog.show();
    }

    private void openPlayStore() {
        final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
        }
    }

    private void checkApplicationVersion() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Application");
        ref.addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        //Get map of users in datasnapshot
                        // Result will be holded Here
                        for (DataSnapshot dsp : dataSnapshot.getChildren()) {
                            if (isForceUpdate((Map<String, Object>) dataSnapshot.getValue())) {
                                Application.setPreferencesBoolean("isForceUpdate", true);
                            } else {
                                Application.setPreferencesBoolean("isForceUpdate", false);
                            }
                            moveToNextScreen();
                            break;
                        }
                    }


                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        moveToNextScreen();

                    }
                });
    }

    private boolean isForceUpdate(Map<String, Object> value) {
        boolean isForceUpdate = false;

        try {
            int versionCode = 0;
            try {
                PackageInfo packageInfo = SplashScreen.this.getPackageManager().getPackageInfo(SplashScreen.this.getPackageName(), 0);
                versionCode = packageInfo.versionCode;
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            if (Integer.parseInt(value.get("AppVersion").toString()) > versionCode) {
                isForceUpdate = true;
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
        return isForceUpdate;
    }

}
