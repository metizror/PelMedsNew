package com.metiz.pelconnect.model;

import java.util.ArrayList;

public class NewModelNeedRifill {
    public ArrayList<ModelNeedRifill> getModelNeedRifillArrayList() {
        return modelNeedRifillArrayList;
    }

    public void setModelNeedRifillArrayList(ArrayList<ModelNeedRifill> modelNeedRifillArrayList) {
        this.modelNeedRifillArrayList = modelNeedRifillArrayList;
    }

    private ArrayList<ModelNeedRifill> modelNeedRifillArrayList;

}
