package com.metiz.pelconnect.model;

public class ModelNotificationDetails {

    /**
     * KeyText : FacilityName
     * ValueText : ADVOCATES INC - 24 BROWNLEA RD
     */

    private String KeyText;
    private String ValueText;

    public String getKeyText() {
        return KeyText;
    }

    public void setKeyText(String KeyText) {
        this.KeyText = KeyText;
    }

    public String getValueText() {
        return ValueText;
    }

    public void setValueText(String ValueText) {
        this.ValueText = ValueText;
    }
}
