package com.metiz.pelconnect.network;

/**
 * Created by espl on 27/9/16.
 */
public class APIConstants {


    public static String device_token = "device_token";
    public static String deviceType = "1";


    public static String order = "order";



}

