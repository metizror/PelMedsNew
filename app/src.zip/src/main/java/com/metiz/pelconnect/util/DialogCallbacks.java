package com.metiz.pelconnect.util;

/**
 * Created by shopify-1 on 25/5/18.
 */

public interface DialogCallbacks {
    void positiveClicked();
    void nagetiveClicked();
    void neutralClicked();
}
