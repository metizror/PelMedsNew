package com.metiz.pelconnect.listeners;

public interface LoaAddedListener {
    void isDrugShiftedToLoa(boolean isLoaShifted);
}
