package com.metiz.pelconnect.util;

/**
 * Created by hp on 29/1/18.
 */

public class GlobalArea {

    public static String selectedFacility = "";

    public static String DONE = "Done";
    public static String INTAKE = "Intake";
    public static String PV2 = "PV2";
    public static String DELIVERED = "Delivered";
    public static String MENIFEST = "Menifest";
    public static String FILLING = "Filling";
    public static boolean isNotificationCliked = false;
}
