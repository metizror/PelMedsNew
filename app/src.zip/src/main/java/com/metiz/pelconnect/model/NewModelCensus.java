package com.metiz.pelconnect.model;

import java.util.ArrayList;

public class NewModelCensus {
    public ArrayList<ModelCensus> getModelCensusArrayList() {
        return modelCensusArrayList;
    }

    public void setModelCensusArrayList(ArrayList<ModelCensus> modelCensusArrayList) {
        this.modelCensusArrayList = modelCensusArrayList;
    }

    private ArrayList<ModelCensus> modelCensusArrayList;

}
