package com.metiz.pelconnect.model;

public class ModelNeedRifill {


    private String KeyText;
    private String ValueText;
    private boolean isDisplayMobile;

    public String getKeyText() {
        return KeyText;
    }

    public void setKeyText(String keyText) {
        KeyText = keyText;
    }

    public String getValueText() {
        return ValueText;
    }

    public void setValueText(String valueText) {
        ValueText = valueText;
    }

    public boolean isDisplayMobile() {
        return isDisplayMobile;
    }

    public void setDisplayMobile(boolean displayMobile) {
        isDisplayMobile = displayMobile;
    }
}
