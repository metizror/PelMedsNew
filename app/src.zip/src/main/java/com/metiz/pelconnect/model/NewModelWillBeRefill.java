package com.metiz.pelconnect.model;

import java.util.ArrayList;

public class NewModelWillBeRefill {
    private ArrayList<WillBeRefill> willBeRefillArrayList;

    public ArrayList<WillBeRefill> getWillBeRefillArrayList() {
        return willBeRefillArrayList;
    }

    public void setWillBeRefillArrayList(ArrayList<WillBeRefill> willBeRefillArrayList) {
        this.willBeRefillArrayList = willBeRefillArrayList;
    }
}
