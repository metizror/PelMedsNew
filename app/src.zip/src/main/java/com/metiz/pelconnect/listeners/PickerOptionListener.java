package com.metiz.pelconnect.listeners;

public interface PickerOptionListener {
    void onTakeCameraSelected();
    void onChooseGallerySelected();
}
