package com.metiz.pelconnect.model;

public class WillBeRefill {

    /**
     * KeyText : Id
     * ValueText : 2213575
     * isDisplayMobile : false
     */

    private String KeyText;
    private String ValueText;
    private boolean isDisplayMobile;

    public String getKeyText() {
        return KeyText;
    }

    public void setKeyText(String KeyText) {
        this.KeyText = KeyText;
    }

    public String getValueText() {
        return ValueText;
    }

    public void setValueText(String ValueText) {
        this.ValueText = ValueText;
    }

    public boolean isIsDisplayMobile() {
        return isDisplayMobile;
    }

    public void setIsDisplayMobile(boolean isDisplayMobile) {
        this.isDisplayMobile = isDisplayMobile;
    }
}
