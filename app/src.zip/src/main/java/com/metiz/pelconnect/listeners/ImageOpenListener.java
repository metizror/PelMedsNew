package com.metiz.pelconnect.listeners;

public interface ImageOpenListener {
}
